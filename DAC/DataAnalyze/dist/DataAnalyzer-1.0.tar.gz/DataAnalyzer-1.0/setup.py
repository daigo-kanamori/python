from setuptools import setup

setup(
    name="DataAnalyzer",
    version='1.0',
    description='python3でデータ解析用のパッケージ',
    author='x',
)
